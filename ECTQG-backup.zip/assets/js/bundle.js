jQuery(document).ready(function( $ ) {

	// scroll to any anchor (with id)
	function scrollToAnchor(aid){
	    var aTag = $("a[name='"+ aid +"']");
	    $('html,body').animate({scrollTop: aTag.offset().top},'slow');
	}

	$("a").click(function() {
		var hrefContent = $(this).attr('href'),
		hrefFirstChar = hrefContent.charAt(0);
		if(hrefFirstChar === '#'){scrollToAnchor(hrefContent.substring(1));}
	});	

});